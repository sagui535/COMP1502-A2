package exceptions;

public class excep {

}
