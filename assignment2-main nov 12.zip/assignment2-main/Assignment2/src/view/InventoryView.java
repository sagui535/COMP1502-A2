package view;

public class InventoryView {

}
